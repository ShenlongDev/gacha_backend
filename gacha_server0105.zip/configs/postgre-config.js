module.exports = {
  "username": "postgres",
  "password": "password",
  "database": "postgres",
  "host": "localhost",
  "dialect": "postgres",
  "logging": false
};