//use your secret
module.exports = {
  secret: "GachaGame"
}
