module.exports = {
  "username": "gachax_db_user",
  "password": "l88nlZBQrolsf79TpG6qNpXD1Fk3gQxp",
  "database": "gachax_db",
  "host": "dpg-ctl6vg0gph6c739in61g-a.oregon-postgres.render.com",
  "dialect": "postgres",
  "dialectOptions": {
    ssl: {
      require: true,
      rejectUnauthorized: false
    }
  },
  "logging": false
};
// module.exports = {
//   "username": "gacha_admin",
//   "password": "itMOw88ZcQrlPOswpUAfYW2ZQLOZWED5",
//   "database": "gacha_0o57",
//   "host": "dpg-ctims2dumphs73f4i7u0-a.oregon-postgres.render.com",
//   "dialect": "postgres",
//   "dialectOptions": {
//     ssl: {
//       require: true,
//       rejectUnauthorized: false
//     }
//   },
//   "logging": false
// };